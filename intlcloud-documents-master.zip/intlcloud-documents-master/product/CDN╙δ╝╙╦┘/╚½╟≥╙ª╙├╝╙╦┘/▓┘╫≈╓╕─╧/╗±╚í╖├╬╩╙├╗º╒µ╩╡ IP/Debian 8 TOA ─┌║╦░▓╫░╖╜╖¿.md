## 下载地址
[内核包下载地址>>](http://toakernel-1253438722.cossh.myqcloud.com/linux-image-3.16.43.toa_1.0_amd64.deb)

[内核 Headers 包下载地址>>](http://toakernel-1253438722.cossh.myqcloud.com/linux-headers-3.16.43.toa_1.0_amd64.deb)

## 安装方法
同 [Ubuntu 16.04 TOA 内核安装方法](/document/product/608/14430)。
