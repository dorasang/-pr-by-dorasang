## Download Links
[Kernel Packet>>](http://toakernel-1253438722.cossh.myqcloud.com/linux-image-3.16.43.toa_1.0_amd64.deb)

[Kernel Headers Packet>>](http://toakernel-1253438722.cossh.myqcloud.com/linux-headers-3.16.43.toa_1.0_amd64.deb)

## Installation Method
See [How to install Ubuntu 16.04 TOA kernel](/document/product/608/14430)。

