﻿### ファイルのダウンロード
- [ダウンロードアドレス>>](https://mc.qcloudimg.com/static/archive/5e5b31b327f3bbdd395ce426cccc3d08/windows_toa.zip)

- 解凍パスワード：Qcloud
- ファイルの説明：
WinPcap_4_1_3.exe：WinPcapドライバーです。詳細については、[WinPcapドキュメント](https://www.winpcap.org/)を参照してください。
lib_toa.lib：静的ライブラリ。
toa_fetcher.h：静的ライブラリが依存するヘッダファイル。
pcap.h：静的ライブラリが依存するヘッダファイル。

###  インストールと追加
1. WinPcapドライバーのインストール：WinPcap_4_1_3.exeをダブルクリックします（システムを再起動する必要はありません）。
2. lib_toa.libをサーバープロジェクトのlibライブラリパスに追加します。
3. toa_fetcher.h，pcap.hをサーバープロジェクトのヘッダファイルに追加します。
