### Downloading the File
- [Download link>>](https://mc.qcloudimg.com/static/archive/5e5b31b327f3bbdd395ce426cccc3d08/windows_toa.zip)

- Decompression password: Qcloud
- Description:
WinPcap_4_1_3.exe: WinPcap drive. For more information, please see [WinPcap documentation](https://www.winpcap.org/).
lib_toa.lib: Static library.
toa_fetcher.h: Header file that the static library is dependent on.
pcap.h: Header file that the static library is dependent on.

### Installing and Adding
1. Install the winpcap drive: Double-click WinPcap_4_1_3.exe (don't need to restart the system).
2. Add lib_toa.lib to the server project's lib library.
3. Add toa_fetcher.h and pcap.h to the server project's header file.

