###  파일 다운로드
- [다운로드 주소>>](https://mc.qcloudimg.com/static/archive/5e5b31b327f3bbdd395ce426cccc3d08/windows_toa.zip)

- 압축 해제 비밀번호: Qcloud
- 파일 설명: 
WinPcap_4_1_3.exe: WinPcap 부팅, 자세한 설명은 [WinPcap 문서](https://www.winpcap.org/)를 참조하십시오.
lib_toa.lib: 정적 라이브러리.
toa_fetcher.h: 정적 라이브러리가 의존하는 헤더 파일.
pcap.h: 정적 라이브러리가 의존하는 헤더 파일.

###  설치와 추가
1. winpcap 부팅 설치: WinPcap_4_1_3.exe를 더블 클릭합니다(시스템을 재부팅할 필요없음).
2. lib_toa.lib를 서버 프로젝트의 lib 라이브러리 경로에 추가합니다.
3. toa_fetcher.h, pcap.h를 서버 프로젝트의 헤더 파일에 추가합니다.

