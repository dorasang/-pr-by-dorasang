[Cloud monitoring] 제품에서 대응하는 알람 규칙을 구성할 수 있습니다. 가속 연결이 알람 조건에 다다르자만자 알람을 트리거합니다. 
[[Cloud monitoring]](https://console.cloud.tencent.com/monitor/policylist/add) 콘솔에 로그인하면 다음 작업을 수행할 수 있습니다.

## 가속 연결 모니터링
1. [Cloud monitoring]>[나의 알람]>[알람 전략] 페이지에서 [알람 전략 추가]를 클릭하여 전략 새로 추가 페이지에 진입합니다.
2. [전략 유형]에서 [GAAP]>[가속 연결]을 선택합니다.
 '알람 전략'에서, '공중망 인바운드 대역폭', '공인망 아웃바운드 대역폭'과 '동시 발생' 세 가지 알람 대상을 지원합니다. 다음 그림과 같습니다.
![](https://main.qcloudimg.com/raw/c99345621523fcf7376401505f3abeb2.png)

## 수신기 모니터링
1. [Cloud monitoring]>[나의 알람]>[알람 전략] 페이지에서 [알람 전략 추가]를 클릭하여 전략 새로 추가 페이지에 진입합니다.
2. [전략 유형]에서 [GAAP]>[가속 연결 수신기]를 선택합니다.
 ‘알람 전략’에서 현재 ‘수신기 오리진 서버 상태 이상’ 알람을 지원하여 오리진 서버 상태가 이상할 경우, Cloud monitoring이 알람을 트리거합니다. 다음 그림과 같습니다. 
![](https://main.qcloudimg.com/raw/f09e16deefabaea97a1a5b475f819ee3.png)

