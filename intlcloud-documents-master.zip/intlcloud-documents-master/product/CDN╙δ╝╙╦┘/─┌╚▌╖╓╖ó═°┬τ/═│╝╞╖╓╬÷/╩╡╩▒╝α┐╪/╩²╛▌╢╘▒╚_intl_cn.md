新版实时监控页面的各子页面，均支持数据曲线对比功能。
1. 登录 [CDN 控制台](https://console.cloud.tencent.com/cdn)，在左侧目录中，单击【统计分析】>【实时监控】，进入管理页面。
2. 查询指定时间区间监控曲线后，单击【数据对比】，指定时间周期，即可进行数据对比展示。
![](https://main.qcloudimg.com/raw/f0c7dd17f0a9434eaf7b3873bbfa860b.png)
为了方便您的使用，指定开始时间后，系统将自动往后补齐结束时间；指定结束时间，系统将自动向前补齐开始时间，保证对比的时间周期一致。
![](https://main.qcloudimg.com/raw/91a7382c709fef8070e2fdac13ecba76.png)