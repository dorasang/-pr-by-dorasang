新版实时监控页面支持按需调整指标面板，方便您查看所关注指标的监控曲线。
1. 登录 [CDN 控制台](https://console.cloud.tencent.com/cdn)，在左侧目录中，单击【统计分析】>【实时监控】，进入管理页面。
2. 单击右侧配置图标，进入配置页面。
 ![](https://main.qcloudimg.com/raw/361fe39905fa49a705a3b34624dfedf1.png)
3. 按需选择在总览页展示的数据指标：被勾选中的指标，将在概览页直接展示，取消勾选，将默认不再展示。
实时监控【访问监控】和【回源监控】总览页面，均可分别配置自定义面板。
 ![](https://main.qcloudimg.com/raw/a0481dd20a3ba63d1c84e72cc9e8846b.png)
