If your billing method is Pay by Traffic, you can purchase a traffic package for cost saving. You can check the usage of traffic package in CDN Console to keep track of the balance of traffic package in real time and top it up in time so that your use of CDN services will not be affected.



Log in to [CDN Console](https://console.cloud.tencent.com/cdn) and select **Advanced** page. You'll see the **Traffic Package Management** feature provided by CDN:



![](https://mc.qcloudimg.com/static/img/11adb0f7ada7a92397a7e78b314965f9/1.png)



This page provides the history of purchase and usage of traffic packages.
