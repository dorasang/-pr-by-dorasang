CDN is a <font col or="red">post-paid product</font>, which means you can pay for it after use, and don't need to pay for it in advance.

Log in to [Tencent Cloud CDN Official Webpage](https://cloud.tencent.com/product/cdn.html), and click "Experience":
![](https://mc.qcloudimg.com/static/img/bcea61432dc4ca66f5287a42264c4a59/1.png)

CDN is a postpaid product which requires identity verification:
![](https://mc.qcloudimg.com/static/img/9edd00a6dc99368b1a4c1bbe1b111dcc/2.png)
If you have already passed the identity verification, skip this step.

After verification, select the billing method to activate the CDN service:
![](//mc.qcloudimg.com/static/img/1c03a50e58d3f7081ed4f7ef77f88a99/image.png)

If you choose "Pay by Traffic", you can purchase a traffic package from which the traffic consumed will be deducted, [Click to Purchase](http://manage.qcloud.com/shoppingcart/shop.php?tab=cdn).
