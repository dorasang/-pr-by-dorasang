### Automatic Reply
Currently, most customer services are simple Q&As. TICSR can accuately intepret customers questions, find accurate answers in knowledge base and reply automatically, cutting up to 80% customer service costs.

### Business Process Directions
TICSR identifies customer intentions and provides guidelines, methods and relavant links, improving efficiency and customer satisfaction.

### Human Customer Service Representative
Human customer service representative function is seamlessly connected with the replies provided by robots, enabling representatives to focus on complex questions and high-value customers and generating higher value out of their work.

### Human Customer Service Assistance
Robots can assist representatives and improve efficiency. Robots can quickly find answers in the knowledge base and answers can be selected and confirmed by human representatives. Human-robot collaboration provides prompt services to more customers.
