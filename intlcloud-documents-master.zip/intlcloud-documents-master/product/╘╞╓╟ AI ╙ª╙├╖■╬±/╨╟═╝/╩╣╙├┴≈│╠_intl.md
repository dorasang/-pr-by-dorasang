﻿SKG can be activated in the following five steps:
![](https://mc.qcloudimg.com/static/img/050acaf4965ebee389284297776890df/image.svg)

## I. Online Application
Click **Contact Sales** on the [SKG product page](https://cloud.tencent.com/product/skg) to enter the application page, fill out the corresponding product application form and submit it for online application. After submitting your application, please allow some time for us to contact you.
## II. Reviewing and Confirming
After receiving your service application, we will preliminarily review and confirm your needs and arrange business negotiation.
## III. Contract Signing
After your needs are confirmed and the negotiation is completed, you will sign a purchase contract with Tencent Cloud and pay the applicable fees.
## IV. Platform Deployment
Our dedicated personnel will complete the offline deployment of the platform for you.
## V. Acceptance
You can test the platform and confirm the report to complete the acceptance process.
