### Do I need to apply for Face Recognition access?
Yes. You can log in to the [Face Recognition console](https://console.cloud.tencent.com/aiface) and click **Activate now** to use it without waiting for manual approval.

### In which countries and regions can Face Recognition be used?
Currently, it can be used in mainland China, Hong Kong, Taiwan, and Singapore. Its APIs can be called in other countries and regions, but there might be access latencies.

### What is the access speed of Face Recognition?
Usually around 200 ms to 1 s, depending on photo sizes and network environment.

### Does Face Recognition support calls by sub-account?
No. We expect to launch this feature in mid-April.


