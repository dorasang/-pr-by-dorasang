### At what confidence level will image-based liveness detection conclude that the person in the image is a real person?
The confidence level recommended by the algorithm is 87 which can be adjusted based on your actual business needs.

### Does image-based liveness detection support video recognition?
It only supports detecting images. It is recommended to screencap the video for recognition.


### In what scenarios can image-based liveness detection be used?
It is recommended to use it in the mobile selfie scenario; otherwise, the reference value of the liveness score will be significantly reduced. This feature is recommended for use cases with low attack defense requirements. We recommend lip language-based liveness detection for high security requirements.
