Click the instance name on the instance list page to go to the instance details page to see the detailed information of the instance.
![](https://main.qcloudimg.com/raw/5be594c2b855417b9945bd2c3c1184a7.png)
The details page includes the instance name, ID, running status, region, creation time, start time, run time (run time of the instance when it starts last time), total run time (total time that the instance runs when it starts and stops for multiple times) and the number of computing resources it used.
You can modify the instance name directly on the page except when the instance is "in operation".
