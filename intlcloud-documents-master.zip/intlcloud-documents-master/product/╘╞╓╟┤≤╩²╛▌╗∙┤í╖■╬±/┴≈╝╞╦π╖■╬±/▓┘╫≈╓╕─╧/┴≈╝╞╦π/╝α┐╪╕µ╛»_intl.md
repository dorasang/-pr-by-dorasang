The following dimensions are monitored:
- Data volume (input and output) per second in bytes/sec.
- Recordings (input and output) per second in pieces/sec.
- CPU/Memory utilization.
- Average processing time.
- Average data latency.
