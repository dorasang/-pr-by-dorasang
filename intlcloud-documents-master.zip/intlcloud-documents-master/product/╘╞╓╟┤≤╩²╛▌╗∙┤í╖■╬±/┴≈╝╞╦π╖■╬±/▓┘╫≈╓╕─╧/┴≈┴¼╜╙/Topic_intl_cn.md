###  创建 Topic
1. 单击先前创建的工程名称，进入该工程。
2. 单击【新建 Topic】按钮，在弹出的页面中填写 Topic 的信息。
其中，类型的选择有三种。
tuple：最常用的类型，表明数据为文本格式。
blob：用于数据为二进制类型的 （暂不能与流计算配合使用）。
upsert：流连接导出数据到CDB中，并希望对已有记录做更新时，选择该项。
![](https://main.qcloudimg.com/raw/84b3d1446877a3d4e964713ff3c03428.png)

### 查看 Topic
单击 Topic 列表下的 Topic 名称查看 Topic 信息。
![](https://main.qcloudimg.com/raw/434f0f1457e5d0727affdd33b76070ce.png)
### 删除 Topic
需将 Topic 下所有 Integrator 删除后才能删除 Topic。
![](https://main.qcloudimg.com/raw/c15f721cb59ca98edf57cb1060cda448.png)