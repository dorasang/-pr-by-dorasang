### Create a Project
Click **Stream Connector** -> **New Project** on the console and enter related information.
![](https://main.qcloudimg.com/raw/072e1af6b2d8c2c4fd396db1c7965bbc.png)

The project will be displayed in the project list after it is created.
![](https://main.qcloudimg.com/raw/47e83a96657f3e7940af45007bb11a79.png)
### View a Project
Click the project name in the list to view its information.
![](https://main.qcloudimg.com/raw/0c0f34b99c8f2ac2d13d97012b71a242.png)

### Delete a Project
A project cannot be deleted until all the resources under it are deleted.
![](https://main.qcloudimg.com/raw/79f7a03c81e4352f1fca591c57e8282a.png)
