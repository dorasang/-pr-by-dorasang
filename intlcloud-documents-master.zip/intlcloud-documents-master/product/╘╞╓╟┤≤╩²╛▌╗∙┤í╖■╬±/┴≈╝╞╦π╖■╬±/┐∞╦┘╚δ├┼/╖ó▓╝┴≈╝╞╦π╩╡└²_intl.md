When configuring the instance, you need to set the number of resources to be used (1CU indicates 1-core CPU and 4 GB memory), whether to enable CheckPoint, and the time interval between CheckPoints.
After all the configurations are completed, click **Save and Launch** to launch and start the instance, which may take several minutes.
![](https://main.qcloudimg.com/raw/c90b7194bf3ec2c2c2cd4c49c7b0ec78.png)
When the status of the instance is changed to "Running", it indicates that the instance has been launched and the stream computing is already running continuously.

