可通过调用 cdp sdk 往 topic 里导入数据，具体请参考 [dataGenerator.zip](https://main.qcloudimg.com/raw/0316a47b3f808b0e6116af95b5ef7beb.zip)。
其中 endpoint 信息在 project 里可查：
![](https://main.qcloudimg.com/raw/0298401e85fe5f9285644ef450440087.png)
secretId&secretKey：在【个人账户】>【访问管理】>【云API密钥】>【API密钥】里可查。
projectName&topicName：是之前创建时指定的相关信息。
导入完成后可通过 SDK 读取数据，也可以通过 Web 查看当前数据量是否新增。
![](https://main.qcloudimg.com/raw/55ff4f5bd596a54a27dc68c83982def7.png)
