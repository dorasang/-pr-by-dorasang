You can import data to a topic by calling the Stream Connector SDK. For more information, see [dataGenerator.zip](https://main.qcloudimg.com/raw/0316a47b3f808b0e6116af95b5ef7beb.zip).
The endpoint information can be found in project:
![](https://main.qcloudimg.com/raw/0298401e85fe5f9285644ef450440087.png)
Go to **User Account** -> **Access Management** -> **Cloud API Key** -> **API Key** to obtain the SecretId and SecretKey.
ProjectName and TopicName are specified during the process of creation.
After data is imported, you can read data using the SDK or check if there is new data through Web.
![](https://main.qcloudimg.com/raw/55ff4f5bd596a54a27dc68c83982def7.png)

