1. Click **Stream Compute** in the left navigation bar on the SCS console to go to the stream compute system.

2. Click the **New** button on the upper left of the page to go to the analysis instance creation page.
Select the region, enter the instance name and set the CU of analysis resource on this page. Then click **Buy Now** to finish the instance creation.
![image](https://main.qcloudimg.com/raw/58fb3b2c46f1ffa81c55c3937af9d6ca.png)

3. After the attributes are configured, click **Buy Now** to return to the instance list. The billing won't begin until the instance is running.

