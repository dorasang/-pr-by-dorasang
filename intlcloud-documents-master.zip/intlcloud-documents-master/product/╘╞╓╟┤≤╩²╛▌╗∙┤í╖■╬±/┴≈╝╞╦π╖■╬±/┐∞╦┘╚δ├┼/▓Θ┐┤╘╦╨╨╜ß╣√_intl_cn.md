## 在流计算查看
在“线上运维”模块中可以看到已上线的实例情况，包括线上正跑的 SQL 语句、参数，以及抽样的源数据记录和计算结果记录，这里展示的都是明细数据，最终聚合后的结果可前往 CDB 查看。
![](https://main.qcloudimg.com/raw/bfb725e7ba6d5252f995f496cadfdb26.png)
![](https://main.qcloudimg.com/raw/851c5dd9dcac6c75ebd0acb4cd66dba5.png)
## 在 CDB 中查看结果
在前面步骤中我们通过配置了输出 CDP 的 Integrator 并启动 Integrator 服务，流计算的结果通过流连接就能直接输出到 CDB，并在 CDB 控制台查看结果。
