## Viewing Results in SCS
You can check the launched instances in the **Online OPS** module, including SQL statements running online, parameters, sampled source data and computing results. The module shows all detailed data, and the aggregated results can be found in CDB.
![](https://main.qcloudimg.com/raw/bfb725e7ba6d5252f995f496cadfdb26.png)
![](https://main.qcloudimg.com/raw/851c5dd9dcac6c75ebd0acb4cd66dba5.png)
## Viewing Results in CDB
In previous steps, you have configured an integrator to output Stream Connector data and started the integrator service. The stream computing results are directly output to CDB through Stream Connector, and can be viewed on the CDB console.

