聚合函数的函数名和功能描述如下：

| 函数名 | 功能描述 | 
| ----- | ----- |
| COUNT(value [, value]\* ) | 返回非 NULL value 的输入行数。|
| COUNT(\*) | 返回输入的行数。|
| AVG(numeric)  | 返回指定列的所有输入的算术平均值。|
| SUM(numeric)  | 返回指定列的所有输入和。|
| MAX(value)  | 返回指定列所有输入的最大值（注：不可用于 TIMESTAMP 类型）。|
| MIN(value)  | 返回指定列所有输入的最小值（注：不可用于 TIMESTAMP 类型）。|
| STDDEV_POP(value) | 计算指定列所有输入的总体标准差。|
| STDDEV_SAMP(value)  | 计算指定列所有输入的样本标准差。|
| VAR_POP(value)  | 计算指定列所有输入的总体方差。|
| VAR_SAMP(value) | 计算指定列所有输入的样本方差。|
| COLLECT(value)  | 返回指定列所有非 NULL 输入的集合（允许重复值）。如果所有值都是 NULL，则返回一个空集。|
