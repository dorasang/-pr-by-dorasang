### CU
CU（Compute Unit）是流计算所提供计算资源的最小单位，1CU 的具体含义为： CPU：1核；内存：4G。 计费的标准就是用户实际的 CU 使用量。

### Integrator
流连接数据集成任务（Integrator）：将 Topic 的数据导入到云产品的任务，一个 Topic 可启动多个 Integrator 导入到不同的云产品。

### Partition
流连接分区（Partition）：Topic 存储数据的最小单元，对于吞吐量较高的 Topic，可以创建多个分区。

### Project
工程（Project）：流连接数据的基本组织单元,下面包含多个 Topic，类似于数据库中库（Database）的概念。

### Topic
主题（Topic）：Topic是流连接订阅和发布的最小单位，用户可以用 Topic 来表示一类或者一种流数据，类似于数据库中的表（Table）的概念。




